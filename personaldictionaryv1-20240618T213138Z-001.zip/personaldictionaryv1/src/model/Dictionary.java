package model;

import java.util.List;

public class Dictionary {
    private String word;
    private int definitionId;
    private int definitionNumber;
    private List<String> definitions;

    public Dictionary(String word, int definitionId,int definitionNumber, List<String> definitions) {
        this.word = word;
        this.definitionId = definitionId;
        this.definitionNumber = definitionNumber;
        this.definitions = definitions;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public int getDefinitionId() {
        return definitionId;
    }

    public void setDefinitionId(int definitionId) {
        this.definitionId = definitionId;
    }

    public int getDefinitionNumber() {
        return definitionNumber;
    }

    public void setDefinitionNumber(int definitionNumber) {
        this.definitionNumber = definitionNumber;
    }

    public List<String> getDefinitions() {
        return definitions;
    }

    public void setDefinitions(List<String> definitions) {
        this.definitions = definitions;
    }
}
