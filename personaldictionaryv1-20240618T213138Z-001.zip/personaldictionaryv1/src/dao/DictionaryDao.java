package dao;

import model.Dictionary;

public interface DictionaryDao {

    Dictionary getDictionaryById(int userId);
    Dictionary createDictionary(int userId);
    Dictionary updateDictionary(int userId);
    Dictionary deleteDictionary(int userId);

}
