package dao;

import model.Dictionary;
//import org.springframework.jdbc.core.JdbcTemplate;

public class JdbcDictionaryDao implements DictionaryDao {

   // private final JdbcTemplate template;
    @Override
    public Dictionary getDictionaryById(int userId) {
        return null;
    }

    @Override
    public Dictionary createDictionary(int userId) {
        return null;
    }

    @Override
    public Dictionary updateDictionary(int userId) {
        return null;
    }

    @Override
    public Dictionary deleteDictionary(int userId) {
        return null;
    }
}
