import java.sql.SQLOutput;
import java.util.Scanner;

public class App {

    final String DICTIONARY_MENU = "Personal Dictionary Menu";
    final String ADD_WORD = "Add New Word to Personal Dictionary";
    final String EXIT = "Exit";
    final String[] MENU_OPTIONS = {DICTIONARY_MENU, ADD_WORD, EXIT};

    boolean finished = false;

    public void run() {
        displayMenu();
    }

    private void displayMenu() {

        printMainMenu();
        int selection = printMainMenu();
            if (selection == 1) {
                printPersonalDictionaryMenu();
            } else if (selection == 2) {
                printAddWordMenu();
            } else if (selection == 0) {
                System.out.println("Please enter a valid number");
                printMainMenu();
            }
        }



    private int printMainMenu() {
        Scanner input = new Scanner(System.in);
        System.out.println("PERSONAL DICTIONARY V1.0");
        System.out.println("------------------------");
        System.out.println("1: " + DICTIONARY_MENU);
        System.out.println("2: " + ADD_WORD);
        System.out.println("0: " + EXIT);
        System.out.println("Please enter your selection: ");
        String inputNumberString = input.nextLine();
        int inputNumber = Integer.parseInt(inputNumberString);
        return inputNumber;
    }

    private int printPersonalDictionaryMenu() {
        Scanner input = new Scanner(System.in);
        System.out.println("DISPLAY OPTIONS:");
        System.out.println("------------------------");
        System.out.println("1: Display all words");
        System.out.println("2: Search for exact word");
        System.out.println("3: Search for partial word");
        System.out.println("0: Exit");
        System.out.println("Please enter your selection: ");
        String inputNumberString = input.nextLine();
        int inputNumber = Integer.parseInt(inputNumberString);
        return inputNumber;
    }

    private int printAddWordMenu() {
        Scanner input = new Scanner(System.in);
        System.out.println("ADD AND UPDATE OPTIONS:");
        System.out.println("------------------------");
        System.out.println("1: Add new word to personal dictionary");
        System.out.println("2: Update word in personal dictionary");
        System.out.println("0: " + EXIT);
        System.out.println("Please enter your selection: ");
        String inputNumberString = input.nextLine();
        int inputNumber = Integer.parseInt(inputNumberString);
        return inputNumber;
    }

}
