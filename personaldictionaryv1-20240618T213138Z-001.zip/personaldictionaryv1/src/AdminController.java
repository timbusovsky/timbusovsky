public class AdminController {


    public AdminController() {

    }
}
